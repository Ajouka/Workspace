public interface Ilist {
    void insertAt(int index,int element);
    void removeAt(int index);
    int getAt(int index);
    int search(int element);
    void clear();
    int getCount();
}
